import{R as o}from"./codemirror-core-vkcnXJgD.js";import{a0 as t}from"./index-CRxYmROf.js";const s=()=>o.useContext(t);export{s as u};
