import{j as t}from"./codemirror-core-vkcnXJgD.js";import{O as r}from"./react-dom-Cz0lLOn1.js";function s(){return t.jsx(r,{})}export{s as default};
